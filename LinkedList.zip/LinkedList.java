public class LinkedList{
  Node first;
  Node last;

  LinkedList(){
    this.first = null;
    this.last = null;
  }

  public class Node{
    int data;
    Node next;
    Node(int input){
      data = input;
    }
  }

  //adds new data to the end of the linked list
  public void add(int newData) {
    Node newNode = new Node(newData);
    newNode.next = null;
    
    if (this.first == null) {
      this.first = newNode;
      this.last = newNode;
    } 
    else {
      this.last.next = newNode;
      this.last = newNode;
    }
  }

  //deletes all occurances of element key
  public void deleteAll(int key) {
    while (this.first != null && this.first.data == key) {
      this.first = this.first.next;
    }
    Node traverser = this.first;
    while (traverser != null && traverser.next != null) {
      if (traverser.next.data == key) {
        traverser.next = traverser.next.next;
      }
      traverser = traverser.next;
    }
    setLast();
  }

  //deletes first occurance of element key
  public void deleteFirst(int key) {
    if (this.first != null && this.first.data == key) {
      this.first = this.first.next;
    } 
    else {
      Node traverser = this.first;
      while (traverser != null && traverser.next.data != key) {
        traverser = traverser.next;
      }
      traverser.next = traverser.next.next;
    }
    setLast();
  }

  //deletes last occurance of element key
  public void deleteLast(int key) {
    Node currMatch = null;
    Node traverser = this.first;
    while (traverser != null && traverser.next != null) {
      if(traverser.next.data == key){
        currMatch = traverser;
      }
      traverser = traverser.next;
    }
    if(currMatch != null) {
      currMatch.next = currMatch.next.next;
    }
    else if(this.first.data == key) {
      this.first = this.first.next;
    }
    setLast();
  }

  public boolean contains(int key) {
    Node traverser = this.first;
    while(traverser != null && traverser.next != null) {
      if(traverser.data == key) {
        return true;
      }
    }
    return false;
  }

  public void printReverse() {
    Node traverser = this.first;
    printReverse();
    System.out.print(traverser.data + " ");
  }

  public void print() {
    Node traverser = this.first;
    System.out.println("");
    while(traverser != null){
      System.out.print(traverser.data + " ");
      traverser = traverser.next;
    }
  }

  private void setLast() {
    Node traverser = this.first;
    while(traverser != null && traverser.next != null) {
      traverser = traverser.next;
    }
    this.last = traverser;
  }
}