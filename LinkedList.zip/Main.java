class Main {
  public static void main(String[] args) {

    //simple example
    LinkedList list = new LinkedList();
    list.add(4);
    list.add(3);
    list.add(9);
    list.add(5);
    list.add(4);
    list.add(5);
    list.add(3);
    list.add(4);
    list.add(5);

    list.print();

    list.deleteAll(5);

    list.print();

    list.add(7);

    list.print();

    list.deleteLast(4);

    list.print();

    list.deleteFirst(4);

    list.print();

  }
}